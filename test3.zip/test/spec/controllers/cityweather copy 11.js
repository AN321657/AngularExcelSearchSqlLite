'use strict';

describe('Controller: CityweatherCtrl', function () {

  // load the controller's module
  beforeEach(module('weatherReportApp'));

  var CityweatherCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    CityweatherCtrl = $controller('CityweatherCtrl', {
      $scope: scope
      // place here mocked dependencies
    });
  }));

  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
   it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });
  it('generate cloud icon dynamically', function () {
    expect(scope.getIconImageUrl('10d')).toBe('http://openweathermap.org/img/w/10d.png');
  });

});
